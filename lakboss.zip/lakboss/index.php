
<?php 

// inclure le fichier de base de donnee
include('inc/bd.php');

// inclure le fichier root.php
include('inc/root.php');
session_start();



$views = scandir('views/');
// print_r($views); 
    if(isset($_GET['page']) && !empty($_GET['page']) && in_array($_GET['page'].'.php',$views)){
        $page = $_GET['page'];
    }else{
        $page = 'home';
    }
// echo $page;

 // inclure les traitement des fichiers 
$views_traitement = scandir('traitement/');
if(in_array('trait_'.$page.'.php' ,$views_traitement)){
    include 'traitement/trait_'.$page.'.php';
}


// inclure les header des fichiers
$hearder = scandir('hearder/');
if(in_array('header_'.$page.'.php' ,$hearder)){
    include 'hearder/header_'.$page.'.php';
}


// inclure les differentes pages 
include('views/'.$page.'.php');

// inclure les fichiers js
            $views_js = scandir('assets/js/');
            if(in_array($page.'.js',$views_js)){
                ?>
                    <script src="assets/js/<?= $page ?>.js"></script>
                <?php
            }
?>


