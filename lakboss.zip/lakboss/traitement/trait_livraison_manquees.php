<?php 
     $exep="Echec";
     $sql="SELECT * FROM commande WHERE statut='{$exep}'";
    $query=$conn->query($sql);  
    $result=$query->fetchAll();
    $count = 1;
  ?>