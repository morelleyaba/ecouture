<?php 
     $exep="Success";
     $sql="SELECT * FROM commande WHERE statut='{$exep}'";
    $query=$conn->query($sql);  
    $result=$query->fetchAll();
    $count = 1;
  ?>