 <?php 

if(!isset($_SESSION['id_admin'])){
	header("Location:index.php?page=signin");
}
?>
<?php
// Assign the search button to get data through post method
 $search = $_POST["searchBox"];
// SQL query to featch the details of a country

$sql = "SELECT * FROM commande,register WHERE code_commande LIKE '$search%' AND commande.id_register=register.id_register"; 
// execution of the query. Output a boolean value
$res = mysqli_query($connect, $sql);
// Take the number of rows of countries starting with the entered word phrase
$count = mysqli_num_rows($res);

?>