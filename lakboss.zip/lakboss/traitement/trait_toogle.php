 <?php
//insert.php
 $code=$_GET['id'];

if(isset($_POST["hidden_gender"]))
{
 $connect = new PDO("mysql:host=localhost;dbname=ecouture", "root", "");
 $query = "
 UPDATE commande
SET statut = :statut
WHERE code_commande = :code_commande
 ";

 $statement = $connect->prepare($query);
 $statement->execute(
  array(
   ':code_commande'   => $code,
   ':statut'  => $_POST['hidden_gender']
  )
 );

 $result = $statement->fetchAll();
 if(isset($result))
 {
  echo 'done';
 }
}

?>