<?php
 


if (isset($_POST['login'])) {
$email = mysqli_real_escape_string($connect, $_POST['email']);
$password = mysqli_real_escape_string($connect, $_POST['password']);

if(!filter_var($email,FILTER_VALIDATE_EMAIL)) {
$email_error = "Veuillez entre une adresse valide";
}
if(strlen($password) < 6) {
$password_error = "Mot de passe assez court";
} 
$pwd=md5($password);
$result = mysqli_query($connect, "SELECT id_admin FROM admin WHERE email = '" . $email. "' and password = '" . $pwd. "'");
if ($row = mysqli_fetch_array($result)) {
    
    $_SESSION['id_admin'] = $row['id_admin'];
    header("Location:index.php?page=home");
} else {
$error_message = "email ou mot de passe incorrect!!";
}
}
?>


