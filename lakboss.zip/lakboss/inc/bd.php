<?php

/* $conn= new PDO("mysql:host=localhost; dbname=ecouture",'root','');*/

 try{
 	$conn= new PDO("mysql:host=localhost; dbname=ecouture",'root','');
 }catch(PDOException $e){
 	die("Erreur de connexion à la base de donnée: " . $e->getMessage());
 }
 
 ?>

<?php

//build the connection variable and assign database credentials
$connect = mysqli_connect('localhost','root','','ecouture');

//if DB connection fails, get a error message
if(!$connect){
    die('Connection Failed'.mysqli_connect_error());
}

?>
