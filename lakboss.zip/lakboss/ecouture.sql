-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : mer. 24 mars 2021 à 02:17
-- Version du serveur :  10.4.18-MariaDB
-- Version de PHP : 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `ecouture`
--

-- --------------------------------------------------------

--
-- Structure de la table `admin`
--

CREATE TABLE `admin` (
  `id_admin` int(11) NOT NULL,
  `email` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `admin`
--

INSERT INTO `admin` (`id_admin`, `email`, `password`) VALUES
(1, 'morelle@gmail.com', '123456');

-- --------------------------------------------------------

--
-- Structure de la table `article`
--

CREATE TABLE `article` (
  `id_article` int(11) NOT NULL,
  `model_unity` varchar(200) NOT NULL,
  `nom_article` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `article`
--

INSERT INTO `article` (`id_article`, `model_unity`, `nom_article`) VALUES
(1, 'unityM32', 'robe'),
(2, 'unityM75', 'ensemble tailleure'),
(3, 'unityMD3', 'combinaison'),
(4, 'unityM11', 'traditionnelle dan');

-- --------------------------------------------------------

--
-- Structure de la table `commande`
--

CREATE TABLE `commande` (
  `id_commande` int(11) NOT NULL,
  `id_register` int(11) NOT NULL,
  `code_commande` int(11) NOT NULL,
  `model_unity` varchar(200) NOT NULL,
  `lieu_livraison` varchar(200) NOT NULL,
  `date_commande` date NOT NULL,
  `date_livraison` date DEFAULT NULL,
  `statut` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `commande`
--

INSERT INTO `commande` (`id_commande`, `id_register`, `code_commande`, `model_unity`, `lieu_livraison`, `date_commande`, `date_livraison`, `statut`) VALUES
(1, 2, 3456, 'unityM32', 'saint-viateur', '0000-00-00', NULL, 'en attente'),
(2, 1, 7457, 'unityM75', 'libreville', '0000-00-00', NULL, 'en cour'),
(3, 1, 9567, 'unityMD3', 'sogefia', '2021-03-21', NULL, 'echecs'),
(4, 3, 74779, 'unityM11', 'Vallon', '2021-03-17', NULL, 'effectuee');

-- --------------------------------------------------------

--
-- Structure de la table `mensuration`
--

CREATE TABLE `mensuration` (
  `id_mensuration` int(11) NOT NULL,
  `id_register` int(11) NOT NULL,
  `taille` varchar(200) NOT NULL,
  `epaule` double NOT NULL,
  `tour_de_taille` double NOT NULL,
  `poitrine` double NOT NULL,
  `manche` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `mensuration`
--

INSERT INTO `mensuration` (`id_mensuration`, `id_register`, `taille`, `epaule`, `tour_de_taille`, `poitrine`, `manche`) VALUES
(1, 1, 'S', 45, 43, 65, 32),
(2, 3, 'M', 75, 47, 63, 24),
(3, 2, 'M', 64, 43, 63, 24);

-- --------------------------------------------------------

--
-- Structure de la table `register`
--

CREATE TABLE `register` (
  `id_register` int(11) NOT NULL,
  `nom` varchar(200) NOT NULL,
  `numero` varchar(20) NOT NULL,
  `mdp` varchar(200) NOT NULL,
  `ville` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `register`
--

INSERT INTO `register` (`id_register`, `nom`, `numero`, `mdp`, `ville`, `email`) VALUES
(1, 'morelle yepie', '3456789', 'yabamorelle', 'ISSIA', 'zert@hj'),
(2, 'alix tchimou', '876543', 'tchimou123', 'DALOA', 'hgfds@hgfds'),
(3, 'ines', '876546', 'ines1234', 'ABIDJAN', 'sdfgh@fghj');

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `email` varchar(20) NOT NULL,
  `pwd` varchar(20) NOT NULL,
  `username` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id_admin`);

--
-- Index pour la table `article`
--
ALTER TABLE `article`
  ADD PRIMARY KEY (`id_article`);

--
-- Index pour la table `commande`
--
ALTER TABLE `commande`
  ADD PRIMARY KEY (`id_commande`);

--
-- Index pour la table `mensuration`
--
ALTER TABLE `mensuration`
  ADD PRIMARY KEY (`id_mensuration`);

--
-- Index pour la table `register`
--
ALTER TABLE `register`
  ADD PRIMARY KEY (`id_register`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `admin`
--
ALTER TABLE `admin`
  MODIFY `id_admin` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT pour la table `article`
--
ALTER TABLE `article`
  MODIFY `id_article` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT pour la table `commande`
--
ALTER TABLE `commande`
  MODIFY `id_commande` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT pour la table `mensuration`
--
ALTER TABLE `mensuration`
  MODIFY `id_mensuration` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT pour la table `register`
--
ALTER TABLE `register`
  MODIFY `id_register` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
