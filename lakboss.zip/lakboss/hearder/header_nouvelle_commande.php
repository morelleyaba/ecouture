<?php 

if(!isset($_SESSION['id_admin'])){
	header("Location:index.php?page=signin");
}
?>

<html lang="en">
<head>
	<meta charset="utf-8" />
	<title>liste commande</title>
	<meta name="viewport" content="initial-scale=1.0; maximum-scale=1.0; width=device-width;">
    <link rel="stylesheet" type="text/css" href="<?=$css?>styles.css">
</head>

<body style="background-image: url(assets/dashboard/images/hero_bg.jpg);">