  
    <div class="col-lg-12">
	    <div class="col-lg-3"></div>
	    <div class="col-lg-6">
			<table class="table table-bordered">

<?php
// Check if there are rows matched with the query
if($count>0)
{
    // Output the details within a table with Bootstrap styes
	while($data = mysqli_fetch_assoc($res)){

        echo '<tr>';
        echo "<td>".'Code'."</td>"."<td>".$data['code_commande']."</td>"; 
        echo '</tr>';

        echo '<tr>';
        echo "<td>".'Vetement'."</td>"."<td>".$data['model_unity']."</td>";
        echo '</tr>';

        echo '<tr>';
        echo "<td>".'Nom Client'."</td>"."<td>".$data['nom']."</td>";
        echo '</tr>';

        echo '<tr>';
        echo "<td>".'Lieu de livraison'."</td>"."<td>".$data['lieu_livraison']."</td>";
        echo '</tr>';

        echo '<tr>';
        echo "<td>".'Ville'."</td>"."<td>".$data['ville']."</td>";
        echo '</tr>';

        echo '<tr>';
        echo "<td>".'Numero de telepone'."</td>"."<td>".$data['numero']."</td>";
        echo '</tr>';

        echo '<tr>';
        echo "<td>".'Date de la commande'."</td>"."<td>".$data['date_commande']."</td>";
        echo '</tr>';

        echo '<tr>';
        echo "<td>".'Date Livraison'."</td>"."<td>".$data['date_livraison']."</td>";
        echo '</tr>';

        echo '<tr>';
        echo "<td>".'statut'."</td>"."<td>".$data['statut']."</td>";
        echo '</tr>';

 		echo '</table>';
	}
}
// If there are no matching countries this will displayed in the browser
else {
	echo "No Data";
}

?><br>
<!-- Return button to the input page -->
               <center>
                    <a href="index.php?page=home" class="btn btn-default">Retour</a>
                </center>
		</div>
      
        <div class="col-lg-3">
         <?php include('toogleEchec.php') ?>
        </div>
        
	</div>
</body>
</html>
