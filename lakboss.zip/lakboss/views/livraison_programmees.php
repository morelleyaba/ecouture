 
    
    <div class="col-lg-12">
        <div class="col-lg-3"></div>
        <div class="col-lg-6">
            <h2 style="margin-top: 100px;">e-couture</h2>
            <br>  
            <form action="index.php?page=search" method="POST">
                <center>
                    <label>Veuillez saisir le Code d'une commande</label>
                </center>
                <br><br>
                <input type="text" id="searchBox" name="searchBox" class="form-control" autocomplete="off" placeholder="Entrer le code de la commande" required="required">
                <div id="result">
                    
                </div>
                 <center>
                    <button class="btn btn-primary">Rechercher</button>
                </center>               
            </form>   
            <div class="success"></div>  

        </div> 
        <div class="col-lg-3"></div>    
    </div>
    <script>
        $(document).ready(function(){
            $('#searchBox').keyup(function(){
                var query = $('#searchBox').val();

                if(query.length>0){
                    $.ajax({
                        url: "",
                        method: "POST",
                        data: {
                           search : 1,
                           q: query 
                        },
                        success:function(data){
                            $('#result').html(data);
                        },
                        dataType: "text"
                    });
                }
            });

            $(document).on('click', 'li', function(){

                var code_commande = $(this).text();
                $('#searchBox').val(code_commande);
                $('#result').html("");

            });
        });

    </script>
    
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>    
</body>
</html>
