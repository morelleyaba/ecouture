 
<section> 
<div class="table-title">
<h3>Nouvelles commandes</h3>
</div>
<br>
 <br>
<table class="table-fill">
<thead>
<tr>
<th class="text-left">Code Commande</th>
<th class="text-left">Type Article</th>
<th class="text-left">Action</th>
</tr>
</thead>
<tbody class="table-hover">
<?php foreach ($result as $row):
    $sql="SELECT nom_article FROM article WHERE model_unity='{$row['model_unity']}'";
    $query=$conn->query($sql);  
    $result=$query->fetch();
    $article=$result['nom_article'];
    
    ?>   
<tr>
<td class="text-left"><?= $row['code_commande']?></td>
<td class="text-left"><?=$article?></td>
<td class="text-left"> <a href="index.php?page=infos_commande&id=<?= $row['code_commande']?>" style="text-decoration:none;"> Voir Plus</a></td>
</tr>
<?php endforeach ?>
</tbody>
</table>
</section>
<?php
include('inc/footer.php');
?>