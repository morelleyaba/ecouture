


	
	  <div class="limiter">
		<div class="container-login100" style="background-image: url('<?=$root_signin?>images/bg-01.jpg');">
			<div class="wrap-login100 p-t-30 p-b-50">
				<span class="login100-form-title p-b-41">
					Administrateur
				</span>
				
				<form class="login100-form validate-form p-b-33 p-t-5" action="" method="post">
				<B><span class="text-danger">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php if (isset($error_message)) echo $error_message; ?></span></B>

					<div class="wrap-input100 validate-input" data-validate = "Enter username">
						<input class="input100" type="text" name="email" placeholder="Votre email">
						<span class="focus-input100" data-placeholder="&#xe82a;"></span>
						
					</div>
					<span class="text-danger"><?php if (isset($email_error)) echo $email_error; ?></span>
					<div class="wrap-input100 validate-input" data-validate="Enter password">
						<input class="input100" type="password" name="password" placeholder="Votre mot de passe">
						<span class="focus-input100" data-placeholder="&#xe80f;"></span>
						
					</div>
					<span class="text-danger"><?php if (isset($password_error)) echo $password_error; ?></span>
					<div class="container-login100-form-btn m-t-32">
						<button  type="submit" value="login" name="login" class="login100-form-btn">
						Connexion
						</button>
					</div>

				</form>
			</div>
		</div>
	</div>
	

	<div id="dropDownSelect1"></div>
	
<!--===============================================================================================-->
	<script src="<?=$root_signin?>vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script src="<?=$root_signin?>vendor/animsition/js/animsition.min.js"></script>
<!--===============================================================================================-->
	<script src="<?=$root_signin?>vendor/bootstrap/js/popper.js"></script>
	<script src="<?=$root_signin?>vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="<?=$root_signin?>vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
	<script src="<?=$root_signin?>vendor/daterangepicker/moment.min.js"></script>
	<script src="<?=$root_signin?>vendor/daterangepicker/daterangepicker.js"></script>
<!--===============================================================================================-->
	<script src="<?=$root_signin?>vendor/countdowntime/countdowntime.js"></script>
<!--===============================================================================================-->
	<script src="<?=$root_signin?>js/main.js"></script>

</body>
</html>