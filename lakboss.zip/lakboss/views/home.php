
	
	<!-- Loader -->
	<div class="fh5co-loader"></div>
	
	<div id="fh5co-page">
		<section id="fh5co-header">
			<div class="container">
				<nav role="navigation">
					<ul class="pull-left left-menu">
						<li><a href="#">Apropos de nous</a></li>
						<li><a href="#">Nous contacter</a></li>
						
					</ul>
					<!-- <h1 id="fh5co-logo"><a href="index.html">guide<span>.</span></a></h1> -->
					<ul class="pull-right right-menu">
						
					 	<li class="fh5co-cta-btn"><a href="index.php?page=logout">Deconnexion</a></li>
						 
					</ul>
				</nav>
			</div>
		</section>
		<!-- #fh5co-header -->

		<section id="fh5co-hero" class="js-fullheight" style="background-image: url(<?=$root ?>/images/Screenshot.jpg);" data-next="yes">
			<div class="fh5co-overlay"></div>
			<div class="container">
				<div class="fh5co-intro js-fullheight">
					<div class="fh5co-intro-text">
						<!-- 
							INFO:
							Change the class to 'fh5co-right-position' or 'fh5co-center-position' to change the layout position
							Example:
							<div class="fh5co-right-position">
						-->
						<div class="fh5co-left-position">
							<B><h2 class="animate-box">Bienvenu sur la page administration</h2></B>
							<p class="animate-box">
							<!-- <a href="https://vimeo.com/channels/staffpicks/93951774" class="btn btn-outline popup-vimeo btn-video">
							<i class="icon-play2"></i> Watch video</a> -->
							 <a href="#" target="_blank" class="btn btn-primary">E-Couture</a></p>
						</div>
					</div>
				</div>
			</div>
			<div class="fh5co-learn-more animate-box">
				<a href="#" class="scroll-btn">
					<span class="text">Afficher le tableau de bord</span>
					<span class="arrow"><i class="icon-chevron-down"></i></span>
				</a>
			</div>
		</section>
		<!-- END #fh5co-hero -->


		<section style="background-color:#ececec" id="fh5co-projects">
			<div class="container">
				<div class="row row-bottom-padded-md">
					<div class="col-md-6 col-md-offset-3 text-center">
						<h3 class="fh5co-lead animate-box">Dashboard</h3>
						
					</div>
				</div>
				<div class="row">
					
					<div class="col-md-4 col-sm-6 col-xxs-12 animate-box">
						<a href="index.php?page=nouvelle_commande" class="fh5co-project-item">
							<img src="<?=$root ?>images/2.png" style=" width:100%;height:100%" alt="Image" class="img-responsive">
							<div class="fh5co-text">
								<h2 style="background-color:#8dc63f;color:white;border-radius: 50px">Nouvelles commandes</h2>
								
							</div>
						</a>
					</div>

					<div class="col-md-4 col-sm-6 col-xxs-12 animate-box">
						<a href="index.php?page=livraison_programmees" class="fh5co-project-item">
							<img src="<?=$root ?>images/1.png" style=" width:100%;height:100%" alt="Image" class="img-responsive">
							<div class="fh5co-text">
								<h2 style="background-color:#8dc63f;color:white;border-radius: 50px">Livraisons en cours</h2>
								
							</div>
						</a>
					</div>

					<div class="col-md-4 col-sm-6 col-xxs-12 animate-box">
						<a href="index.php?page=livraison_effectuees" class="fh5co-project-item">
							<img src="<?=$root ?>images/3.png" style=" width:100%;height:100%" alt="Image" class="img-responsive">
							<div class="fh5co-text">
								<h2 style="background-color:#8dc63f;color:white;border-radius: 50px">Livraisons effectuées</h2>
								
							</div>
						</a>
					</div>

					<div class="col-md-4 col-sm-6 col-xxs-12 animate-box">
						<a href="index.php?page=livraison_manquees" class="fh5co-project-item">
							<img src="<?=$root ?>images/4.png" style=" width:100%;height:100%" alt="Image" class="img-responsive">
							<div class="fh5co-text">
								<h2 style="background-color:#8dc63f;color:white;border-radius: 50px">Livraisons echouée</h2>
								
							</div>
						</a>
					</div>

					<div class="col-md-4 col-sm-6 col-xxs-12 animate-box">
						<a href="#" class="fh5co-project-item">
							<img src="<?=$root ?>images/5.png" style=" width:100%;height:100%" alt="Image" class="img-responsive">
							<div class="fh5co-text">
								<h2 style="background-color:#8dc63f;color:white;border-radius: 50px">Statistiques</h2>
								
							</div>
						</a>
					</div>

					<div class="col-md-4 col-sm-6 col-xxs-12 animate-box">
						<a href="#" class="fh5co-project-item">
							<img src="<?=$root ?>images/6.png" style=" width:100%;height:100%" alt="Image" class="img-responsive">
							<div class="fh5co-text">
								<h2 style="background-color:#8dc63f;color:white;border-radius: 50px">Enregistrer de nouveaux articles</h2>
								
							</div>
						</a>
					</div>
					
					
				</div>
			</div>
		</section>
		<!-- END #fh5co-projects -->


		<footer id="fh5co-footer">
			<div class="container">
				<div class="row row-bottom-padded-md">
					<div class="col-md-3 col-sm-6 col-xs-12 animate-box">
						<div class="fh5co-footer-widget">
							<h3>Company</h3>
							<ul class="fh5co-links">
								<li><a href="#">About Us</a></li>
								<li><a href="#">Careers</a></li>
								
							</ul>
						</div>
					</div>

					<div class="col-md-3 col-sm-6 col-xs-12 animate-box">
						<div class="fh5co-footer-widget">
							<h3>Support</h3>
							<ul class="fh5co-links">
								<li><a href="#">Knowledge Base</a></li>
								<li><a href="#">24/7 Call Support</a></li>
								
							</ul>
						</div>
					</div>

					<div class="col-md-3 col-sm-6 col-xs-12 animate-box">
						<div class="fh5co-footer-widget">
							<h3>Contact Us</h3>
							<p>
								<a href="mailto:info@freehtml5.co">info@freehtml5.co</a> <br>
								
								<a href="tel:+123456789">+12 34  5677 89</a>
							</p>
						</div>
					</div>

					<div class="col-md-3 col-sm-6 col-xs-12 animate-box">
						<div class="fh5co-footer-widget">
							<h3>Follow Us</h3>
							<ul class="fh5co-social">
								<li><a href="#"><i class="icon-twitter"></i></a></li>
								<li><a href="#"><i class="icon-facebook"></i></a></li>
								<li><a href="#"><i class="icon-google-plus"></i></a></li>
								<li><a href="#"><i class="icon-instagram"></i></a></li>
								<li><a href="#"><i class="icon-youtube-play"></i></a></li>
							</ul>
						</div>
					</div>

				</div>
				
			</div>
			
		</footer>
		<!-- END #fh5co-footer -->
	</div>
	<!-- END #fh5co-page -->
	
	<!-- For demo purposes Only ( You may delete this anytime :-) -->
	
	<!-- End demo purposes only -->

	
	<!-- jQuery -->
	<script src="<?=$root ?>js/jquery.min.js"></script>
	<!-- jQuery Easing -->
	<script src="<?=$root ?>js/jquery.easing.1.3.js"></script>
	<!-- Bootstrap -->
	<script src="<?=$root ?>js/bootstrap.min.js"></script>
	<!-- Waypoints -->
	<script src="<?=$root ?>js/jquery.waypoints.min.js"></script>
	<!-- Flexslider -->
	<script src="<?=$root ?>js/jquery.flexslider-min.js"></script>
	<!-- Magnific Popup -->
	<script src="<?=$root ?>js/jquery.magnific-popup.min.js"></script>
	<script src="<?=$root ?>js/magnific-popup-options.js"></script>

	<!-- For demo purposes only styleswitcher ( You may delete this anytime ) -->
	<script src="<?=$root ?>js/jquery.style.switcher.js"></script>
	
	<!-- End demo purposes only -->

	<!-- Main JS (Do not remove) -->
	<script src="<?=$root ?>js/main.js"></script>

	<!-- 
	INFO:
	jQuery Cookie for Demo Purposes Only. 
	The code below is to toggle the layout to boxed or wide 
	-->
	<script src="<?=$root ?>js/jquery.cookie.js"></script>
	
	

	</body>
</html>

