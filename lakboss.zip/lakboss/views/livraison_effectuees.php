 
<section> 
<div class="table-title">
<h3>Livraisons effectuees</h3>
</div>
<br>
 <br>
<table class="table-fill">
<thead>
<tr>
<th class="text-left">Code Commande</th>
<th class="text-left">Type Article</th>
<th class="text-left">NOM</th>

</tr>
</thead>
<tbody class="table-hover">
<?php foreach ($result as $row):
    $sql="SELECT nom_article FROM article WHERE model_unity='{$row['model_unity']}'";
    $query=$conn->query($sql);  
    $result=$query->fetch();
    $article=$result['nom_article'];
    
$array=array();

$queryy = "SELECT * FROM register WHERE id_register='{$row['id_register']}' "; 
$sqly=$conn->query($queryy);
$resulty=$sqly->fetchAll();
foreach ($resulty as $nb) {
$array[]=$nb;
}



    ?>  





<tr>
<td class="text-left"><?= $row['code_commande']?></td>
<td class="text-left"><?=$article?></td>
<td class="text-left"><?=$nb['nom']?></></td>

</tr>
<?php endforeach ?>
</tbody>
</table>
</section>
<?php
include('inc/footer.php');
?>