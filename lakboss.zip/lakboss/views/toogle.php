
   <form style="margin-left: 80%" method="post" id="insert_data">
    <div class="form-group">
     <div class="checkbox">
      <input type="checkbox" name="statut" id="statut"/>
     </div>
    </div>
    <input type="hidden" name="hidden_gender" id="hidden_gender" value="En cour" />
   </form>


<script>
$(document).ready(function(){
 
 $('#statut').bootstrapToggle({
  on: 'En cour',
  off: 'En Attente',
  onstyle: 'success',
  offstyle: 'danger'
 });

 $('#statut').change(function(){
  if($(this).prop('checked'))
  {
   $('#hidden_gender').val('En cour');
  }
  else
  {
   $('#hidden_gender').val('En Attente');
  }
 });



 $('#statut').on('change', function(event){
  event.preventDefault();
  
   var form_data = $('#hidden_gender');
   $.ajax({
    url:"",
    method:"POST",
    data:(form_data),
    success:function(data){
     if(data == 'done')
     {
      $('#insert_data')[0].reset();
      $('#statut').bootstrapToggle('on');
      alert("Data Inserted");
     }
    }
   });
 });

});
</script>
