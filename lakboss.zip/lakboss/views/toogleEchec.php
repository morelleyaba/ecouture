
<?php 

 try{
  $conn= new PDO("mysql:host=localhost; dbname=ecouture",'root','');
 }catch(PDOException $e){
  die("Erreur de connexion à la base de donnée: " . $e->getMessage());
 }
 
 
$code='3456';
if (isset($_POST['send'])) {

$statut = isset($_POST['statut'])?$_POST['statut']:null;

$date_livraison =$_POST['date_livraison'];

if (!empty($statut)&& !empty($date_livraison)&& isset($statut)&& isset($date_livraison)) {

  $requet=$conn->query("UPDATE commande SET statut ='{$statut}', date_livraison='{$date_livraison}' WHERE code_commande ='{$code}'
  ");

  if ($requet) {
   echo "coool";
   header("Location:index.php?page=livraison_programmees");
  }else echo 'dommage';
} else echo 'champs vide';

}
?>

<form style="margin-left: 20%" action="" method="POST">
  <h3>Mettre a jour</h3><label for="Echec">
<input type="radio" id="Echec" name="statut" value="Echec">
Echec</label>
<br>
<label for="Success">
<input type="radio" id="Success" name="statut" value="Success">
Success</label>
<br><br>
<label>Date</label><br>
<input type="date" name="date_livraison">
<br><br>
          <button  type="submit" value="" name="send" class="login100-form-btn">
            mettre a jour
            </button>
</form>